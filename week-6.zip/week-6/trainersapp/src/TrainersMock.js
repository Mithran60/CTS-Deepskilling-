const trainers = [
    {
        trainerId: 1,
        name: "John Doe",
        email: "john@example.com",
        phone: "1234567890",
        technology: "React",
        skills: "React, Redux, JS"
    },
    {
        trainerId: 2,
        name: "Jane Smith",
        email: "jane@example.com",
        phone: "9876543210",
        technology: "Angular",
        skills: "Angular, TypeScript, HTML"
    }
];

export default trainers;
