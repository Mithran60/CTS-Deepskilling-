package com.library.service;

public class BookService {
    public void serve() {
        System.out.println("Serving book...");
    }
}
