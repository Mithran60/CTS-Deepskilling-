package com.documents;

public interface Document {
    void open();
}