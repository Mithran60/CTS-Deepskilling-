function Home() {
    return <h2>Welcome to the My Academy Trainers App</h2>;
}

export default Home;
