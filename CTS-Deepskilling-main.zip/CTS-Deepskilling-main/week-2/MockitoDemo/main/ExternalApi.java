package com.example;

public interface ExternalApi {
    String getData();
}
