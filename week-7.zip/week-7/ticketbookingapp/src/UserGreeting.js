import React from 'react';

function UserGreeting() {
  return <h1>Welcome back</h1>;
}

export default UserGreeting;
